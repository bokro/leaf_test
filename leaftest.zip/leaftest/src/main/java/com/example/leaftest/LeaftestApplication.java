package com.example.leaftest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeaftestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeaftestApplication.class, args);
	}

}
