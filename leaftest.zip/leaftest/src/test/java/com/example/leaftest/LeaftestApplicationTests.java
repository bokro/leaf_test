package com.example.leaftest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaftestApplicationTests {

	@Test
	void contextLoads() {
	}

}
